#!/usr/bin/env python3
"""
Predicting Antimicrobial Resistance (AMR) from Bacterial Gene Sequences
Using a pretrained genomic language model (Nucleotide Transformer)

WHAT THIS SCRIPT DOES
----------------------
Given a raw DNA sequence of a bacterial gene, predicts which antibiotic drug
class it most likely confers resistance to -- using embeddings from a
pretrained genomic language model instead of hand-built features.

Pipeline:
  1. Download & parse the CARD (Comprehensive Antibiotic Resistance Database)
  2. Build a labelled dataset: gene sequence -> drug class
  3. Baseline: k-mer frequency + Logistic Regression (sanity check)
  4. Load a pretrained genomic LLM (Nucleotide Transformer) and extract embeddings
  5. Train a lightweight classifier head on those embeddings
  6. Evaluate (accuracy, per-class recall, confusion matrix) vs. the baseline
  7. Interpretability: occlusion-based importance
  8. Predict on your own pasted-in DNA sequence
  9. Look up documented resistance genes by organism name

IMPORTANT -- pinned `transformers` version
-------------------------------------------
Install with:  pip install -r requirements.txt
The Nucleotide Transformer models are loaded via trust_remote_code=True, which
pulls in custom model code from the model's own Hugging Face repo. That code
still imports a helper function (find_pruneable_heads_and_indices) from
transformers.pytorch_utils -- newer transformers releases (5.x) removed it,
and not every model size's custom code has been updated to match. Installing
the newest transformers will break model loading with an ImportError, which is
why requirements.txt pins transformers==4.53.0.

USAGE
-----
  # Full run: download data, train baseline + LLM classifier, evaluate
  python amr_pipeline.py

  # After an initial run, test a sequence without retraining (uses cache)
  python amr_pipeline.py --sequence "ATGCGTACGG..."

  # Look up what CARD has on file for a given organism
  python amr_pipeline.py --organism "Escherichia coli"

  # Force retraining even if a cached model exists
  python amr_pipeline.py --retrain

Citations:
  Alcock et al. (2023). CARD 2023: expanded curation, support for machine
    learning, and resistome prediction at the Comprehensive Antibiotic
    Resistance Database. Nucleic Acids Research.
  Dalla-Torre et al. (2023). The Nucleotide Transformer: Building and
    Evaluating Robust Foundation Models for Human Genomics. bioRxiv.
"""

import argparse
import functools
import os
import pickle
import re
import tarfile
import urllib.request

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")  # headless-safe: always save figures to file, never try to pop up a window
import matplotlib.pyplot as plt
import seaborn as sns
from Bio import SeqIO
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, f1_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.neural_network import MLPClassifier
from tqdm.auto import tqdm

CARD_URL = "https://card.mcmaster.ca/latest/data"
DATA_DIR = "card_data"
OUTPUT_DIR = "outputs"
CACHE_DIR = "model_cache"
CACHE_PATH = os.path.join(CACHE_DIR, "trained_classifier.pkl")

DEFAULT_MODEL_NAME = "InstaDeepAI/nucleotide-transformer-v2-100m-multi-species"


# ---------------------------------------------------------------------------
# Step 1 -- Download and extract CARD
# ---------------------------------------------------------------------------
def download_card(data_dir=DATA_DIR):
    """Download and extract the CARD database. Skips re-downloading if already present."""
    os.makedirs(data_dir, exist_ok=True)
    archive_path = os.path.join(data_dir, "card_data.tar.bz2")

    if not os.path.exists(archive_path):
        print("Downloading CARD database...")
        urllib.request.urlretrieve(CARD_URL, archive_path)
    else:
        print("CARD archive already downloaded, skipping.")

    fasta_check = os.path.join(data_dir, "nucleotide_fasta_protein_homolog_model.fasta")
    if not os.path.exists(fasta_check):
        with tarfile.open(archive_path, "r:bz2") as tar:
            tar.extractall(data_dir)
    return data_dir


# ---------------------------------------------------------------------------
# Step 2 -- Parse sequences and build a labelled dataset
# ---------------------------------------------------------------------------
def parse_card_data(data_dir=DATA_DIR):
    """
    Parse nucleotide_fasta_protein_homolog_model.fasta and join against
    aro_index.tsv to get a drug-class label for every gene sequence.
    Also extracts the organism name in [brackets] at the end of each header.
    """
    fasta_path = os.path.join(data_dir, "nucleotide_fasta_protein_homolog_model.fasta")
    aro_index_path = os.path.join(data_dir, "aro_index.tsv")

    aro_pattern = re.compile(r"ARO:(\d+)")
    organism_pattern = re.compile(r"\[(.*?)\]\s*$")

    records = []
    for rec in SeqIO.parse(fasta_path, "fasta"):
        match = aro_pattern.search(rec.description)
        if not match:
            continue
        organism_match = organism_pattern.search(rec.description)
        records.append({
            "aro_accession": "ARO:" + match.group(1),
            "sequence": str(rec.seq).upper(),
            "length": len(rec.seq),
            "organism": organism_match.group(1) if organism_match else "Unknown",
        })

    seq_df = pd.DataFrame(records)
    aro_index = pd.read_csv(aro_index_path, sep="\t")
    aro_index = aro_index.rename(columns={"ARO Accession": "aro_accession", "Drug Class": "drug_class"})

    data = seq_df.merge(aro_index[["aro_accession", "drug_class"]], on="aro_accession", how="left")
    data = data.dropna(subset=["drug_class"])

    # A gene can be annotated with multiple drug classes separated by '; ' --
    # simplified here to a single-label problem by taking the first listed class.
    # (State this explicitly as a limitation in any write-up.)
    data["primary_drug_class"] = data["drug_class"].str.split(";").str[0].str.strip()

    print(f"Total labelled sequences: {len(data)}")
    return data


def build_train_test(data, top_n_classes=8, min_len=200, max_len=3000, test_size=0.2, random_state=42):
    """Filter to the most frequent drug classes and do a stratified train/test split."""
    top_classes = data["primary_drug_class"].value_counts().head(top_n_classes).index.tolist()
    data_top = data[data["primary_drug_class"].isin(top_classes)].reset_index(drop=True)
    data_top = data_top[(data_top["length"] >= min_len) & (data_top["length"] <= max_len)].reset_index(drop=True)

    print(f"Sequences after filtering: {len(data_top)}")
    print(f"Classes: {top_classes}")

    label_encoder = LabelEncoder()
    data_top["label"] = label_encoder.fit_transform(data_top["primary_drug_class"])

    train_df, test_df = train_test_split(
        data_top, test_size=test_size, stratify=data_top["label"], random_state=random_state
    )
    print(f"Train: {len(train_df)}  Test: {len(test_df)}")
    return train_df, test_df, top_classes, label_encoder


# ---------------------------------------------------------------------------
# Step 3 -- Baseline: k-mer frequency + Logistic Regression
# ---------------------------------------------------------------------------
def kmer_tokenize(seq, k=4):
    return [seq[i:i + k] for i in range(len(seq) - k + 1)]


def train_baseline(train_df, test_df, k=4):
    vectorizer = CountVectorizer(analyzer=lambda s: kmer_tokenize(s, k=k))
    X_train_kmer = vectorizer.fit_transform(train_df["sequence"])
    X_test_kmer = vectorizer.transform(test_df["sequence"])

    baseline_clf = LogisticRegression(max_iter=2000)
    baseline_clf.fit(X_train_kmer, train_df["label"])
    baseline_preds = baseline_clf.predict(X_test_kmer)
    return baseline_clf, vectorizer, baseline_preds


# ---------------------------------------------------------------------------
# Step 4 -- Load the pretrained genomic language model
# ---------------------------------------------------------------------------
def load_llm(model_name=DEFAULT_MODEL_NAME):
    import torch
    from transformers import AutoTokenizer, AutoModelForMaskedLM

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Loading {model_name} on {device}...")

    tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
    model = AutoModelForMaskedLM.from_pretrained(model_name, trust_remote_code=True).to(device)
    model.eval()
    return tokenizer, model, device


# ---------------------------------------------------------------------------
# Step 5 -- Extract embeddings
# ---------------------------------------------------------------------------
def embed_sequences(sequences, tokenizer, model, device, max_tokens=400, batch_size=8):
    import torch

    all_embeddings = []
    for i in tqdm(range(0, len(sequences), batch_size)):
        batch = sequences[i:i + batch_size]
        tokens = tokenizer.batch_encode_plus(
            batch, return_tensors="pt", padding="max_length",
            truncation=True, max_length=max_tokens
        )["input_ids"].to(device)
        attention_mask = (tokens != tokenizer.pad_token_id)
        with torch.no_grad():
            outputs = model(
                tokens, attention_mask=attention_mask,
                encoder_attention_mask=attention_mask, output_hidden_states=True
            )
        hidden = outputs["hidden_states"][-1]
        mask = attention_mask.unsqueeze(-1)
        mean_embeddings = (hidden * mask).sum(dim=1) / mask.sum(dim=1)
        all_embeddings.append(mean_embeddings.cpu().numpy())
    return np.concatenate(all_embeddings, axis=0)


# ---------------------------------------------------------------------------
# Step 6 -- Train classifier head on LLM embeddings
# ---------------------------------------------------------------------------
def train_llm_classifier(X_train_emb, y_train):
    clf = MLPClassifier(hidden_layer_sizes=(128,), max_iter=1000, random_state=42)
    clf.fit(X_train_emb, y_train)
    return clf


# ---------------------------------------------------------------------------
# Step 7 -- Evaluate and compare to baseline
# ---------------------------------------------------------------------------
def evaluate_and_compare(test_df, baseline_preds, llm_preds, label_encoder, output_dir=OUTPUT_DIR):
    os.makedirs(output_dir, exist_ok=True)
    y_true = test_df["label"]

    print("\n--- Baseline (k-mer + Logistic Regression) ---")
    print(classification_report(y_true, baseline_preds, target_names=label_encoder.classes_, zero_division=0))

    print("--- Nucleotide Transformer embeddings + MLP classifier ---")
    print(classification_report(y_true, llm_preds, target_names=label_encoder.classes_, zero_division=0))

    print(f"Baseline accuracy:      {accuracy_score(y_true, baseline_preds):.3f}")
    print(f"LLM-embedding accuracy: {accuracy_score(y_true, llm_preds):.3f}")
    print(f"Baseline macro-F1:      {f1_score(y_true, baseline_preds, average='macro'):.3f}")
    print(f"LLM-embedding macro-F1: {f1_score(y_true, llm_preds, average='macro'):.3f}")

    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    for ax, preds, title in zip(
        axes, [baseline_preds, llm_preds], ["Baseline (k-mer + LogReg)", "Nucleotide Transformer + MLP"]
    ):
        cm = confusion_matrix(y_true, preds)
        sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=label_encoder.classes_,
                    yticklabels=label_encoder.classes_, ax=ax, cbar=False)
        ax.set_title(title)
        ax.set_xlabel("Predicted")
        ax.set_ylabel("True")
        ax.tick_params(axis="x", rotation=90)
    plt.tight_layout()
    out_path = os.path.join(output_dir, "confusion_matrices.png")
    plt.savefig(out_path, dpi=150)
    plt.close(fig)
    print(f"Saved confusion matrix comparison to {out_path}")


# ---------------------------------------------------------------------------
# Step 8 -- Interpretability: occlusion-based importance
# ---------------------------------------------------------------------------
def occlusion_importance(sequence, true_label_idx, embed_fn, clf, window=30, stride=15):
    positions, drops = [], []
    baseline_emb = embed_fn([sequence])
    baseline_prob = clf.predict_proba(baseline_emb)[0][true_label_idx]
    for start in range(0, len(sequence) - window, stride):
        occluded = sequence[:start] + ("N" * window) + sequence[start + window:]
        occ_emb = embed_fn([occluded])
        occ_prob = clf.predict_proba(occ_emb)[0][true_label_idx]
        positions.append(start)
        drops.append(baseline_prob - occ_prob)
    return positions, drops


def plot_occlusion_importance(sequence, true_label_idx, drug_class_name, embed_fn, clf, output_dir=OUTPUT_DIR):
    os.makedirs(output_dir, exist_ok=True)
    positions, drops = occlusion_importance(sequence, true_label_idx, embed_fn, clf)

    plt.figure(figsize=(12, 4))
    plt.plot(positions, drops, marker="o", markersize=3)
    plt.axhline(0, color="gray", linewidth=0.8)
    plt.xlabel("Sequence position (bp)")
    plt.ylabel("Drop in predicted probability when occluded")
    plt.title(f"Occlusion importance -- {drug_class_name} gene")
    plt.tight_layout()
    out_path = os.path.join(output_dir, "occlusion_importance.png")
    plt.savefig(out_path, dpi=150)
    plt.close()
    print(f"Saved occlusion importance plot to {out_path}")


# ---------------------------------------------------------------------------
# Step 9 -- Predict on a pasted-in DNA sequence
# ---------------------------------------------------------------------------
def predict_drug_class(raw_sequence, embed_fn, clf, label_encoder, verbose=True):
    sequence = "".join(raw_sequence.split()).upper()
    valid_bases = set("ACGTN")
    if not set(sequence).issubset(valid_bases):
        bad_chars = set(sequence) - valid_bases
        raise ValueError(f"Sequence contains non-DNA characters: {bad_chars}")

    embedding = embed_fn([sequence])
    probabilities = clf.predict_proba(embedding)[0]
    ranked = sorted(zip(label_encoder.classes_, probabilities), key=lambda x: x[1], reverse=True)

    if verbose:
        print(f"Sequence length: {len(sequence)} bp\n")
        print("Predicted drug class ranking:")
        for drug_class, prob in ranked:
            print(f"  {drug_class:25s} {prob:.1%}")
    return ranked[0][0]


# ---------------------------------------------------------------------------
# Step 10 -- Look up resistance by organism name
# ---------------------------------------------------------------------------
def lookup_organism_resistance(organism_query, data, top_classes, embed_fn, clf, label_encoder,
                                cross_check_with_model=True, max_check=5):
    """
    NOTE on what this does and doesn't mean: each CARD reference sequence is
    tagged with the organism it was originally isolated from when deposited in
    GenBank. This shows genes CARD has documented for that species -- it is
    NOT a guarantee that every individual bacterium of that species carries
    them, and it isn't a live susceptibility result for any specific culture.
    """
    matches = data[data["organism"].str.contains(organism_query, case=False, na=False)]

    if matches.empty:
        print(f"No CARD reference genes tagged with an organism containing '{organism_query}'.")
        print("Try a shorter/partial name -- e.g. 'coli' instead of 'Escherichia coli'.")
        return

    print(f"Found {len(matches)} CARD reference gene(s) tagged with organism containing '{organism_query}'\n")
    print("Documented drug classes among these genes (per CARD curation):")
    print(matches["primary_drug_class"].value_counts().to_string())

    if not cross_check_with_model:
        return

    checkable = matches[matches["primary_drug_class"].isin(top_classes)]
    if checkable.empty:
        print("\n(None of these genes fall within the drug classes the model was trained on,"
              " so no model cross-check is available.)")
        return

    sample_n = min(max_check, len(checkable))
    print(f"\nCross-checking {sample_n} gene(s) against the trained model's own prediction:\n")
    for _, row in checkable.sample(sample_n, random_state=1).iterrows():
        predicted = predict_drug_class(row["sequence"], embed_fn, clf, label_encoder, verbose=False)
        match_mark = "match" if predicted == row["primary_drug_class"] else "differs"
        print(f"  {row['aro_accession']:15s} CARD label: {row['primary_drug_class']:22s} "
              f"Model says: {predicted:22s} ({match_mark})")


# ---------------------------------------------------------------------------
# Caching -- avoid retraining every time you just want a prediction
# ---------------------------------------------------------------------------
def save_cache(clf, label_encoder, top_classes):
    os.makedirs(CACHE_DIR, exist_ok=True)
    with open(CACHE_PATH, "wb") as f:
        pickle.dump({"clf": clf, "label_encoder": label_encoder, "top_classes": top_classes}, f)
    print(f"Saved trained classifier to {CACHE_PATH}")


def load_cache():
    if not os.path.exists(CACHE_PATH):
        return None
    with open(CACHE_PATH, "rb") as f:
        cached = pickle.load(f)
    print(f"Loaded cached classifier from {CACHE_PATH} (use --retrain to force a fresh run)")
    return cached["clf"], cached["label_encoder"], cached["top_classes"]


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(description="AMR drug-class prediction from bacterial gene sequences.")
    parser.add_argument("--sequence", type=str, default=None,
                         help="A raw DNA sequence to classify (letters A/T/G/C/N only).")
    parser.add_argument("--organism", type=str, default=None,
                         help="A bacterium name to search CARD for, e.g. 'Escherichia coli'.")
    parser.add_argument("--top-n-classes", type=int, default=8,
                         help="Number of most frequent drug classes to train on (default: 8).")
    parser.add_argument("--model-name", type=str, default=DEFAULT_MODEL_NAME,
                         help="Hugging Face model name for the genomic language model.")
    parser.add_argument("--max-tokens", type=int, default=400,
                         help="Max tokens per sequence when embedding (default: 400).")
    parser.add_argument("--batch-size", type=int, default=8,
                         help="Batch size for embedding extraction (default: 8).")
    parser.add_argument("--retrain", action="store_true",
                         help="Force retraining even if a cached classifier exists.")
    args = parser.parse_args()

    # Data is needed either way (organism lookups need it; training needs it)
    download_card()
    data = parse_card_data()

    cached = None if args.retrain else load_cache()

    if cached is not None:
        llm_clf, label_encoder, top_classes = cached
        tokenizer, model, device = load_llm(args.model_name)
    else:
        train_df, test_df, top_classes, label_encoder = build_train_test(data, top_n_classes=args.top_n_classes)

        print("\nTraining baseline (k-mer + Logistic Regression)...")
        baseline_clf, vectorizer, baseline_preds = train_baseline(train_df, test_df)

        tokenizer, model, device = load_llm(args.model_name)

        print("\nExtracting embeddings (this is the slow step)...")
        embed_fn_train = functools.partial(
            embed_sequences, tokenizer=tokenizer, model=model, device=device,
            max_tokens=args.max_tokens, batch_size=args.batch_size,
        )
        X_train_emb = embed_fn_train(train_df["sequence"].tolist())
        X_test_emb = embed_fn_train(test_df["sequence"].tolist())

        print("\nTraining classifier head on LLM embeddings...")
        llm_clf = train_llm_classifier(X_train_emb, train_df["label"])
        llm_preds = llm_clf.predict(X_test_emb)

        evaluate_and_compare(test_df, baseline_preds, llm_preds, label_encoder)

        example_row = test_df.iloc[0]
        embed_fn_single = functools.partial(
            embed_sequences, tokenizer=tokenizer, model=model, device=device,
            max_tokens=args.max_tokens, batch_size=1,
        )
        plot_occlusion_importance(
            example_row["sequence"], example_row["label"], example_row["primary_drug_class"],
            embed_fn_single, llm_clf,
        )

        save_cache(llm_clf, label_encoder, top_classes)

    embed_fn = functools.partial(
        embed_sequences, tokenizer=tokenizer, model=model, device=device,
        max_tokens=args.max_tokens, batch_size=1,
    )

    if args.sequence:
        print("\n--- Prediction for your sequence ---")
        predict_drug_class(args.sequence, embed_fn, llm_clf, label_encoder)

    if args.organism:
        print(f"\n--- Organism lookup: {args.organism} ---")
        lookup_organism_resistance(args.organism, data, top_classes, embed_fn, llm_clf, label_encoder)

    if not args.sequence and not args.organism and cached is not None:
        print("\nModel loaded from cache. Pass --sequence \"ATGC...\" or --organism \"Escherichia coli\" to use it.")


if __name__ == "__main__":
    main()
